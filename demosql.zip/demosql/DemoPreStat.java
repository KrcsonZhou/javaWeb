package demosql;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DemoPreStat {
    public static void main(String[] args) throws SQLException, ClassNotFoundException{
        Class.forName("com.mysql.cj.jdbc.Driver");
        
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/demodata?serverTimezone=UTC", "root","wangtong");
        
        // inserts a records
        PreparedStatement stat1 = con.prepareStatement("insert into emp values(?, ?, ?)");
        stat1.setInt(1, 5);
        stat1.setString(2, "James");
        stat1.setInt(3, 34);
        
        int i = stat1.executeUpdate();
        
        System.out.println(i + " record added");
        System.out.println();
        
        // updates a record
        PreparedStatement stat2 = con.prepareStatement("update emp set name=? where id=?");
        
        stat2.setString(1, "Lebron");
        stat2.setInt(2, 5);
        
        int s = stat2.executeUpdate();
        System.out.println(s + " record updated");
        System.out.println();
        
        // delete a record
        PreparedStatement stat3 = con.prepareStatement("delete from emp where id=?");
        stat3.setInt(1, 2);
        int m = stat3.executeUpdate();
        System.out.println(m + " record deleted");
        System.out.println();
        
        //select all table records
        PreparedStatement stat4 = con.prepareStatement("select * from emp");
        ResultSet set = stat4.executeQuery();
        while(set.next()){
            System.out.println(set.getInt(1)+ "  " + set.getString(2) + "   " + set.getInt(3));
        }
    }
}
