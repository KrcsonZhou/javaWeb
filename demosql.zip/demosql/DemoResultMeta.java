package demosql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.ResultSetMetaData;

public class DemoResultMeta {
    public static void main(String[] args)throws ClassNotFoundException, SQLException{
        Class.forName("com.mysql.cj.jdbc.Driver");
        
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/demodata?serverTimezone=UTC", "root", "wangtong");
        
        PreparedStatement stat = con.prepareStatement("select * from emp;");
        ResultSet set = stat.executeQuery();
        ResultSetMetaData metaData = set.getMetaData();
        System.out.println("The total columns is " + metaData.getColumnCount());
        System.out.println("The 1st column name is " + metaData.getColumnName(1));
        System.out.println("Column type name of 2nd column is " + metaData.getColumnTypeName(2));
    }
}
