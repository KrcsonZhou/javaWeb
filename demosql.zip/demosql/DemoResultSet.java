package demosql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DemoResultSet {
    public static void main(String[] args) throws SQLException, ClassNotFoundException{
        Class.forName("com.mysql.cj.jdbc.Driver");
        
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/demodata?serverTimezone=UTC", "root","wangtong");
        
        Statement stat = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
        
        ResultSet set = stat.executeQuery("select * from emp");
        
        set.absolute(3);
        
        System.out.print(set.getInt(1) + "   " + set.getString(2) + "       " + set.getInt(3));
        
        con.close();
    }
}
