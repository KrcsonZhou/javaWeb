package demosql;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.io.IOException;

public class DemoStoreFile {
    public static void main(String[] args) throws ClassNotFoundException, SQLException, FileNotFoundException, UnsupportedEncodingException, IOException{
        Class.forName("com.mysql.cj.jdbc.Driver");
        
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/demodata?serverTimezone=UTC", "root", "wangtong");
        
        PreparedStatement stat = con.prepareStatement("insert into filetable values(?, ?)");
        
        FileInputStream textFile = new FileInputStream("C:/Users/ASUS-1/Desktop/demo.txt");
        Reader textData = new InputStreamReader(new FileInputStream("C:/Users/ASUS-1/Desktop/demo.txt"), "UTF-8");
        
        stat.setInt(1, 101);
        stat.setCharacterStream(2, textData, textFile.available());
        
        int i = stat.executeUpdate();
        
        System.out.println( i + "records affects");
        
        con.close();
    }
        
}
