package demosql;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.CallableStatement;
import java.sql.SQLException;

public class DemoGetStoredProcedure {
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/demodata?serverTimezone=UTC", "root", "wangtong");
        
        CallableStatement stat = con.prepareCall("{call insertRecord(?, ?, ?)}");
        
        stat.setInt(1, 7);
        stat.setString(2, "Ed Sheeran");
        stat.setInt(3, 45);
        
        stat.executeUpdate();
        
        System.out.println("Insert Record Success!!");
        
        con.close();
    }
}
