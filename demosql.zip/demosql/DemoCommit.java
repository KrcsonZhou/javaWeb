package demosql;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class DemoCommit {
    public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException{
        
        Class.forName("com.mysql.cj.jdbc.Driver");
        
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/demodata?serverTimezone=UTC", "root", "wangtong");
        
        con.setAutoCommit(false);
        
        PreparedStatement stat = con.prepareStatement("insert into emp values(?, ?, ?);");
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        
        while(true){
            System.out.println("Enter id: ");
            String ids = reader.readLine();
            int id = Integer.parseInt(ids);
            
            System.out.println("Enter name: ");
            String name = reader.readLine();
            
            System.out.println("Enter age: ");
            int age = Integer.parseInt(reader.readLine());
            
            stat.setInt(1, id);
            stat.setString(2, name);
            stat.setInt(3, age);
            stat.executeUpdate();
            
            System.out.println("Commit or Rollback");
            String require = reader.readLine();
            if(require.equalsIgnoreCase("commit"))
                con.commit();
            if(require.equalsIgnoreCase("rollback"))
                con.rollback();
            
            System.out.println("Insert another record?(y/n)");
            String process = reader.readLine();
            if(process.equalsIgnoreCase("n"))
                break;
        }
        
        con.commit();
        
        System.out.println("Successful insert records");
        
        con.close();
    }
            
}
