package demosql;

import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;

public class DemoFirstSql{
    public static void main(String[] args) throws Exception{
        
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/DemoData?serverTimezone=UTC","root","wangtong");
           Statement stat = con.createStatement(); 
           
           ResultSet set = stat.executeQuery("select * from emp;");
           
           while(set.next())
               System.out.println(set.getInt(1) +"   " +  set.getString(2) + "      " + set.getInt(3));
           
           con.close();
        
    }
            
}