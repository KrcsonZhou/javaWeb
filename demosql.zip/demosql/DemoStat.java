package demosql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DemoStat {
    public static void main(String[] args) throws ClassNotFoundException, SQLException{
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/DemoData?serverTimezone=UTC", "root", "wangtong");
        
        Statement stat = con.createStatement();
        
        stat.executeUpdate("insert into emp value(4, 'Mark', 34)");
        
        int result = stat.executeUpdate("update emp set name='Maceo', age=35 where id=4");
        System.out.println(result + "records affected");
    }     
}
