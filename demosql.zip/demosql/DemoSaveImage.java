package demosql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class DemoSaveImage {
    public static void main(String[] args) throws ClassNotFoundException, FileNotFoundException,SQLException{
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/demodata?serverTimezone=UTC", "root", "wangtong");
        
        PreparedStatement stat = con.prepareStatement("insert into imgtable values(?,?)");
        
        stat.setString(1, "Ya Ya");
        
        stat.setBinaryStream(2, new FileInputStream("D:/workspace/demo2/src/h.jpg"));
        
        int i = stat.executeUpdate();
        
        System.out.println( i + " rows affected");
    }
}
