package demosql;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.NClob;
import java.io.Reader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
public class DemoRetrieveFile {
    public static void main(String[] args) throws IOException, SQLException, FileNotFoundException, ClassNotFoundException{
        Class.forName("com.mysql.cj.jdbc.Driver");
        
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/demodata?serverTimezone=UTC", "root", "wangtong");
        
        PreparedStatement stat = con.prepareStatement("SELECT * FROM FILETABLE");
        ResultSet set = stat.executeQuery();
        
        while(set.next()){
            NClob file = set.getNClob(2);
            
            Reader fileData = file.getCharacterStream();
            
            FileOutputStream filename = new FileOutputStream("G://story.txt");
            OutputStreamWriter writer = new OutputStreamWriter(filename, "UTF-8");
            System.out.println(writer.getEncoding());
            int i;
            while((i = fileData.read()) != -1){
                writer.write((char)i);
            }
            writer.close();
        }
        con.close();
        System.out.println("Retrieve Completed");
    }
}
