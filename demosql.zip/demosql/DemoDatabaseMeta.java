package demosql;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;

public class DemoDatabaseMeta {
    public static void main(String[] args) throws ClassNotFoundException, SQLException{
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/demodata?serverTimezone=UTC", "root", "wangtong");
        
        DatabaseMetaData metaData = con.getMetaData();
        
        System.out.println("Driver Name: " + metaData.getDriverName());
        System.out.println("Driver Version: " + metaData.getDriverVersion());
        System.out.println("User Name: " + metaData.getUserName());
        System.out.println("Database Product Name: " + metaData.getDatabaseProductName());
        System.out.println("Database Product Version: " + metaData.getDatabaseProductVersion());
        System.out.println();
        
        String[] table = {"table"};
        ResultSet set1 = metaData.getTables(null, null,null, table);
        
        while(set1.next())
            System.out.println(set1.getString(3));
        
        System.out.println();
        
        String[] view = {"VIEW"};
        ResultSet set2 = metaData.getTables(null, null, null, view);
        
        while(set2.next())
            System.out.println(set2.getString(3));
        
        
        con.close();
    }
        
}

