package demosql;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Blob;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class DemoRetrieveImage {
    public static void main(String[] args) throws SQLException, ClassNotFoundException, FileNotFoundException, IOException{
        Class.forName("com.mysql.cj.jdbc.Driver");
        
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/demodata?serverTimezone=UTC", "root", "wangtong");
        
        PreparedStatement stat = con.prepareStatement("select * from imgtable");
        ResultSet set = stat.executeQuery();
        
        while(set.next()){
            Blob img = set.getBlob(2);
            
            byte[] imgData = img.getBytes(1, (int)img.length());
            
            FileOutputStream imgFile = new FileOutputStream("G:/Yaya.jpg");
            
            imgFile.write(imgData);
            
            imgFile.close();
        }
        System.out.println("Retrieve Completed");
    }
}
