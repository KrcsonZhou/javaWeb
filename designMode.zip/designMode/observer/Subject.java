public interface Subject{
	
	public void add(Observer obs);
	
	public void remove(Observer obs);
	
	public void notifyObservers();
	
	public void doThis();
}