public class SecondObserver implements Observer{
	
	@Override
	public void update(){
		System.out.println("The second observer had received notification!");
	}
}