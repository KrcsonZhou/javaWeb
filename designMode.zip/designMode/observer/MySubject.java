public class MySubject extends AbstractSubject{
	
	@Override
	public void doThis(){
		System.out.println("The subject is launching!");
		notifyObservers();
	}
}