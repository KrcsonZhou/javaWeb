import java.util.*;
public abstract class AbstractSubject implements Subject{
	
	private Vector<Observer> allObs = new Vector<>();
	
	@Override
	public void add(Observer obs){
		this.allObs.add(obs);
	}
	
	@Override
	public void remove(Observer obs){
		this.allObs.remove(obs);
	}
	
	@Override
	public void notifyObservers(){
		
		Enumeration<Observer> obss = allObs.elements();
		while(obss.hasMoreElements()){
			obss.nextElement().update();
		}
	}
}