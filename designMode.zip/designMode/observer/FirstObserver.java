public class FirstObserver implements Observer{
	
	@Override
	public void update(){
		System.out.println("The first observer received notification!");
	}
}