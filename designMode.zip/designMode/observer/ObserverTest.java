public class ObserverTest{
	
	public static void main(String[] args){
		Subject subject = new MySubject();
		Observer firstObserver = new FirstObserver();
		Observer secondObserver = new SecondObserver();
		
		subject.add(firstObserver);
		subject.add(secondObserver);
		
		subject.doThis();
	}
}