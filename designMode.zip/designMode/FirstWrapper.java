public class FirstWrapper implements AdapterTarget{
	
	private AdapterSource source;
	
	public FirstWrapper(AdapterSource source){
		
		super();
		this.source = source;
	}
	
	@Override
	public void doOther(){
		System.out.println("This is a wrapper that holds a source object");
	}
	
	@Override
	public void getSource(){
		source.getSource();
	}
}