public class FirstBridge extends AbstractBridge{
	
	@Override
	public void doThis(){
		getSource().doThis();
	}
}