public interface Sourceable{
	public void doThis();
}