public class SecondSubsource implements Sourceable{
	
	@Override
	public void doThis(){
		System.out.println("This is source operation for second");
	}
}