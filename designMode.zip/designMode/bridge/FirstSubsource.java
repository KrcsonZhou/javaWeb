public class FirstSubsource implements Sourceable{
	
	@Override
	public void doThis(){
		System.out.println("This is source operation for first");
	}
}