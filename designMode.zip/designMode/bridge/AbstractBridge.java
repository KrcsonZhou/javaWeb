public class AbstractBridge{
	
	private Sourceable source;
	
	public void doThis(){
		source.doThis();
	}
	
	public Sourceable getSource(){
		return source;
	}
	
	public void setSource(Sourceable source){
		this.source = source;
	}
}