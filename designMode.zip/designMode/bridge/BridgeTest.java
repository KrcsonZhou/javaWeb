public class BridgeTest{
	public static void main(String[] args){
		AbstractBridge bridge = new FirstBridge();
	
		Sourceable firstSource = new FirstSubsource();
		bridge.setSource(firstSource);
		bridge.doThis();
	
		Sourceable secondSource = new SecondSubsource();
		bridge.setSource(secondSource);
		bridge.doThis();
	}
}
	