public class AdapterSource{
	public void getSource(){
		System.out.println("This is a first adapter source");
	}
}