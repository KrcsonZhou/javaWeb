public interface ProxySourceable{
	public void doThis();
}