public class ProxySource implements ProxySourceable{
	
	@Override
	public void doThis(){
		System.out.println("This is a source for proxy");
	}
}