public class TreeNode{
	private String name;
	private TreeNode parent;
	private Vector<TreeNode> children = new Vector<>();
	
	public TreeNode(String name){
		this.name = name;
	}
	
	public String getName(){
		return this.name;
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public  TreeNode getParent(){
		return this.parent;
	}
	
	public void setParent(TreeNode parent){
		this.parent = parent;
	}
	
	public void addChild(TreeNode child){
		this.children.add(child);
	}
	
	public void removeChild(TreeNode child){
		this.children.remove(child);
	}
	
	public Enumeration<TreeNode> getChildren(){
		return this.children.elements();
	}
	
}