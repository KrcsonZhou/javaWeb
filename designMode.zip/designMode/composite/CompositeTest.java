public class CompositeTest{
	
	public static void main(String[] args){
		Tree tree = new Tree("root");
		
		TreeNode node1 = new TreeNode("node1");
		TreeNode node2 = new TreeNode("node2");
		
		node1.add(node2);
		tree.root.add(node1);
		
	}
}