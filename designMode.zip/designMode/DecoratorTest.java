public class DecoratorTest{
	public static void main(String[] args){
		DecorSource source = new DecorSource();
		
		FirstDecorator decorator = new FirstDecorator(source);
		
		decorator.doThis();
	}
}