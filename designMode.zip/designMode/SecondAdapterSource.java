public interface SecondAdapterSource{
	
	public void doOneThing();
	public void doOtherThing();
}
	