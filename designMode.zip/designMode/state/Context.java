public class Context{
	
	private State state;
	
	public Context(State state){
		this.state = state;
	}
	
	public void setState(State state){
		this.state = state;
	}
	
	public State getState(){
		return this.state;
	}
	
	public void intoWork(){
		if(state.getValue().equals("first")){
			state.doThis();
			return;
		}
		
		if(state.getValue().equals("second")){
			state.doOther();
			return;
		}
		System.out.println("State Error!");
	}
}
		