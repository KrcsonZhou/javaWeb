public class State{
	
	private String value;
	
	public String getValue(){
		return this.value;
	}
	
	public void setValue(String value){
		this.value = value;
	}
	
	public void doThis(){
		System.out.println("Into first state, ready work: ");
	}
	
	public void doOther(){
		System.out.println("Into second state, ready work: ");
	}
}