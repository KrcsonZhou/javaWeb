public class StateTest{
	public static void main(String[] args){
		State state = new State();
		Context context = new Context(state);
		
		state.setValue("first");
		context.intoWork();
		
		state.setValue("second");
		context.intoWork();
		
		state.setValue("unknown");
		context.intoWork();
	}
}
		