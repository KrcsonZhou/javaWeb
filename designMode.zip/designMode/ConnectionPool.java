import java.sql.*;

public class ConnectionPool{
	
	private Vector<Connection> pool;
	
	private String url = "jdbc:mysql://localhost:3306/demdata?serverTimezone=UTC";
	
	private String user = "root";
	
	private String password = "wangtong";
	
	private String driver = "com.mysql.cj.jdbc.Driver";
	
	
	private int poolSize = 100;
	
	private static ConnectionPool instance = null;
	
	Connection con = null;
	
	private ConnectionPool(){
		
		pool = new Vector<Connection>(poolSize);
		
		for(int i = 0; i < poolSize; i++){
			try{
				Class.forName(driver);
				con = DriverManager.getConnection(url, user, password);
				poll.add(con);
			}catch(ClassNotFoundException ex){
				ex.printStackTrace();
			}catch(SQLException ex){
				ex.printStackTrace();
			}
		}
	}
	
	public synchronized Connection getConnection(){
		if(pool.size() > 0){
			Connection con = pool.get(0);
			pool.remove(con);
			return con;
		}else{
			return null;
		}
	}
	
	public synchronized void release(){
		
		pool.add(con);
	}