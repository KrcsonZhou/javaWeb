public class FirstProxy implements ProxySourceable{
	
	private ProxySource source;
	
	public FirstProxy(){
		super();
		this.source = new ProxySource();
	}
	
	public void doThis(){
		doBefore();
		source.doThis();
		doAfter();
	}
	
	public void doBefore(){
		System.out.println("Before proxy: ");
	}
	
	public void doAfter(){
		System.out.println("After proxy.");
	}
}