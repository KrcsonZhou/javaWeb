public class FirstAdapter extends AdapterSource implements AdapterTarget{
	
	@Override
	public void doOther(){
		System.out.println("This is a Adapter for connnect between source and target");
	}
}