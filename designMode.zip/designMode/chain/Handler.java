public interface Handler{
	public void doThis();
}