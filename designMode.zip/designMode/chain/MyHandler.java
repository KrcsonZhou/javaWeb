public class MyHandler extends AbstractHandler implements Handler{
	
	private String name;
	
	public MyHandler(String name){
		this.name = name;
	}
	
	@Override
	public void doThis(){
		System.out.println(this.name + " handler have been started !");
		if(getHandler() != null){
			getHandler().doThis();
		}
	}
}