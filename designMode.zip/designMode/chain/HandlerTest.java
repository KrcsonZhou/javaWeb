public class HandlerTest{
	public static void main(String[] args){
		
		MyHandler first = new MyHandler("first");
		MyHandler second = new MyHandler("second");
		MyHandler third = new MyHandler("third");
		
		second.setHandler(third);
		first.setHandler(second);
		
		
		
		first.doThis();
	}
}