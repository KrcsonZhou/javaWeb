public class Multiply extends AbstractCalculator implements Calculator{
	
	@Override
	public int calculate(String exp){
		String opt = "\\*";
		int[] array = split(exp, opt);
		
		return array[0] * array[1];
	}
}