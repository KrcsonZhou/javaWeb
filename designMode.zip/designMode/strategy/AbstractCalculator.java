public abstract class AbstractCalculator{
	
	public int[] split(String exp, String opt){
		
		String[] array = exp.split(opt);
		
		int[] numbers = new int[2];
		
		numbers[0] = Integer.parseInt(array[0]);
		
		numbers[1] = Integer.parseInt(array[1]);
		
		return numbers;
	}
}