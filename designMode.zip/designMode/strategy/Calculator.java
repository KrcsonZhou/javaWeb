public interface Calculator{
	
	public int calculate(String exp);
}