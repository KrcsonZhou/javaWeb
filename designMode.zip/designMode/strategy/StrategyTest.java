public class StrategyTest{
	
	public static void main(String[] args){
		String exp1 = "13+14";
		Calculator plus = new Plus();
		System.out.println(plus.calculate(exp1));
		
		String exp2 = "4*13";
		Calculator multiply = new Multiply();
		System.out.println(multiply.calculate(exp2));
	}
}
		