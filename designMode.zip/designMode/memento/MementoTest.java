public class MementoTest{
	public static void main(String[] args){
		
		Original original = new Original("first");
		
		Storage storage = new Storage(original.createMemento());
		
		System.out.println("The first state: " + original.getValue());
		
		original.setValue("second");
		
		System.out.println("The changed state: " + original.getValue());
		
		original.restoreMemento(storage.getMemento());
		
		System.out.println("The restored state: " + original.getValue());
	}
}