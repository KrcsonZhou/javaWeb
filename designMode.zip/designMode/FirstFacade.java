public class FirstFacade {
	private OneSource source1;
	private TwoSource source2;
	
	public FirstFacade(){
		source1 = new OneSource();
		source2 = new TwoSource();
	}
	
	public void doThis(){
		System.out.println("Before facade: ");
		source1.doThis();
		source2.doThis();
		System.out.println("After facade.");
	}
	
	public void doOther(){
		System.out.println("Before facade: ");
		source1.doOther();
		source2.doOther();
		System.out.println("After facade.");
	}
}