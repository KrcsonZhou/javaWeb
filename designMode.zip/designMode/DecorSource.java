public class DecorSource implements DecorSourceable{
	
	@Override
	public void doThis(){
		System.out.println("This is a source class for decoration");
	}
}