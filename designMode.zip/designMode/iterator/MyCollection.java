public class MyCollection implements Collection{
	
	public String[] items = {"A", "B", "C", "D", "E"};
	
	@Override
	public Iterator iterator(){
		return new MyIterator(this);
	}
	
	@Override 
	public Object get(int i){
		return items[i];
	}
	
	@Override
	public int size(){
		return items.length;
	}
}