public class TwoSource{
	public void doThis(){
		System.out.println("This is second source for facade");
	}
	public void doOther(){
		System.out.println("This is another operation for second source");
	}
}