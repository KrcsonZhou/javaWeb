public class ProxyTest {
	public static void main(String[] args){
		FirstProxy proxy = new FirstProxy();
		
		proxy.doThis();
	}
}