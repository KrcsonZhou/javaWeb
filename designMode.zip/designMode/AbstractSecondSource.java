public abstract class AbstractSecondSource implements SecondAdapterSource{
	public void doOneThing(){}
	public void doOtherThing(){}
}