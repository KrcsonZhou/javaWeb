public interface DecorSourceable{
	public void doThis();
}