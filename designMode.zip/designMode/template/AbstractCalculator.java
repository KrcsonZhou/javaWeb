public abstract class AbstractCalculator{
	
	public int calculate(String exp, String opt){
		int[] numbers = split(exp, opt);
		return calculate(numbers[0], numbers[1]);
	}
	
	abstract int calculate(int firstNumber, int secondNumber);
	
	public int[] split(String exp, String opt){
		String[] array = exp.split(opt);
		
		int[] numbers = new int[2];
		
		numbers[0] = Integer.parseInt(array[0]);
		numbers[1] = Integer.parseInt(array[1]);
		
		return numbers;
	}
}