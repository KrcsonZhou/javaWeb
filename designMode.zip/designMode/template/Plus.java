public class Plus extends AbstractCalculator{
	
	@Override
	public int calculate(int firstNumber, int secondNumber){
		
		return firstNumber + secondNumber;
	}
}