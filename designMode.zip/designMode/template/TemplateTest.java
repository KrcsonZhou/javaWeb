public class TemplateTest{
	public static void main(String[] args){
		AbstractCalculator plus = new Plus();
		
		int result = plus.calculate("14+15", "\\+");
		
		System.out.println(result);
	}
}