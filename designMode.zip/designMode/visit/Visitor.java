public interface Visitor{
	public void visit(Subject sub);
}