public class MyVisitor implements Visitor{
	@Override
	public void visit(Subject sub){
		System.out.println("we are visiting the subject: " + sub.getSubject());
	}
}