public class FirstDecorator implements DecorSourceable{
	
	private DecorSource source;
	
	public FirstDecorator(DecorSource source){
		super();
		this.source = source;
	}
	
	@Override
	public void doThis(){
		System.out.println("before decorating: ");
		source.doThis();
		System.out.println("after decorating. ");
	}
}