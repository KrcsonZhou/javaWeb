public class AdapterTest{
	public static void main(String[] args){
		AdapterSource source = new AdapterSource();
		AdapterTarget target = new FirstWrapper(source);
		
		target.getSource();
		target.doOther();
		
		SecondAdapterSource first = new FirstSourceWrapper();
		first.doOneThing();
		first.doOtherThing();
		SecondAdapterSource second = new SecondSourceWrapper();
		second.doOneThing();
		second.doOtherThing();
		
	}
}