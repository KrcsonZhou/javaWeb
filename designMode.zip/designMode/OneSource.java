public class OneSource{
	
	public void doThis(){
		System.out.println("This is first source for facade.");
	}
	
	public void doOther(){
		System.out.println("This is another operation for firstSource.");
	}
}