public class FacadeTest{
	public static void main(String[] args){
		FirstFacade facade = new FirstFacade();
		facade.doThis();
		System.out.println("new do other work: ");
		facade.doOther();
	}
}