public class FirstUser extends User{
	
	public FirstUser(Mediator mediator){
		super(mediator);
	}
	
	@Override
	public void doWork(){
		System.out.println("The first User is working!");
	}
}