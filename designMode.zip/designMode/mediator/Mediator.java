public interface Mediator{
	public void createMediator();
	public void doAllWork();
}