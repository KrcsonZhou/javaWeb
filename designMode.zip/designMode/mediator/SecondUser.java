public class SecondUser extends User{
	
	public SecondUser(Mediator mediator){
		super(mediator);
	}
	
	@Override
	public void doWork(){
		System.out.println("The second User is working!");
	}
}