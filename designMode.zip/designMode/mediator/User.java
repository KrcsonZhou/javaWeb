public abstract class User{
	private Mediator mediator;
	
	public User(Mediator mediator){
		this.mediator = mediator;
	}
	
	public Mediator getMediator(){
		return this.mediator;
	}
	
	public abstract void doWork();
}