public class MyMediator implements Mediator{
	
	private User firstUser;
	private User secondUser;
	
	public User getFirstUser(){
		return firstUser;
	}
	
	public User getSecondUser(){
		return secondUser;
	}
	
	@Override
	public void createMediator(){
		this.firstUser = new FirstUser(this);
		this.secondUser = new SecondUser(this);
	}
	
	@Override
	public void doAllWork(){
		this.firstUser.doWork();
		this.secondUser.doWork();
	}
}