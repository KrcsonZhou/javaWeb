public class SecondSourceWrapper extends AbstractSecondSource{
	
	@Override
	public void doOtherThing(){
		System.out.println("This is another implementation.");
	}
}