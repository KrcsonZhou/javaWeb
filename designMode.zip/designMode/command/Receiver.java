public class Receiver {
	public void doThis(){
		System.out.println("The command received!");
	}
}