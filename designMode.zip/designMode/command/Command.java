public interface Command{
	public void exec();
}