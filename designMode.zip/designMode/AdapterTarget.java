public interface AdapterTarget{
	public void getSource();
	public void doOther();
}
	