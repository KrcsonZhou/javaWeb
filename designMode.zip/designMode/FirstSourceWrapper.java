public class FirstSourceWrapper extends AbstractSecondSource{
	
	public void doOneThing(){
		System.out.println("This is first implementation");
	}
}