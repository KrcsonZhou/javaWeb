package coreJavaVolume22;

public class ScienceBook extends Book
{
	private Book serviceManual;
	
	/**
	 * Constructs a ScienceBook with a secretary
	 * @param n the book's name
	 * @param p the book's price
	 * @param year the buy year
	 * @param month the buy month
	 * @param day the buy day
	 */
	public ScienceBook(String n, double p, int year, int month, int day )
	{
		super(n,p, year, month, day);
		serviceManual = null;
	}
	
	/**
	 * Assigns a serviceManual to the manager
	 * @param s the ServiceManual
	 */
	public void setServiceManual(Book s)
	{
		serviceManual = s;
	}
	
	@Override
	public String toString()
	{
		return super.toString() + ", [serviceManual =" + serviceManual + "]";
	}
}
