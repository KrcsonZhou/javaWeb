package coreJavaVolume22;

public class OneNoteTest {

}
