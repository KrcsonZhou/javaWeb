package coreJavaVolume22;

import java.io.*;

/**
 * @version 1.8.1
 * @author Krcson Zhou  Cover Cay Horstmann
 */
public class ObjectStreamTest 
{
	public static void main(String[] args) throws IOException, ClassNotFoundException
	{
		Book maintain = new Book("The manual of mantain", 10.23, 1990, 05,23);
		ScienceBook math = new ScienceBook("What is mathematics", 43.00, 2017, 04, 23);
		math.setServiceManual(maintain);
		ScienceBook thinking = new ScienceBook("Thinking in Java", 108.00, 2016,9,12);
		thinking.setServiceManual(maintain);
		
		Book[] books = new Book[3];
		
		books[0] = maintain;
		books[1] = math;
		books[2] = thinking;
		
		// save all book records to the file employee.dat
		try(ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("D:/book3.dat")))
		{
			out.writeObject(books);
		}
		
		try(ObjectInputStream in = new ObjectInputStream(new FileInputStream("D:/book3.dat")))
		{
			// retrieve all records into a new array
			
			Book[] bookRecords = (Book[]) in.readObject();
			
			// slide the serviceManual's price
			bookRecords[0].secondHandRate(10);
			
			//print the newly read employee records
			for (Book b : bookRecords)
				System.out.println(b);
		}
	}
}
