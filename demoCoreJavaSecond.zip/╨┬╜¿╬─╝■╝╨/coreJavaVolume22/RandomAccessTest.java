package coreJavaVolume22;

import java.io.*;
import java.util.*;
import java.time.*;

/**
 * This programe demonstrates the random access file that write and read.
 * @version 1.8.0
 * @author Krcson override Cay Horstmann
 */
public class RandomAccessTest 
{
	public static void main(String[] args) throws IOException
	{
		Book[] books = new Book[3];
		
		books[0] = new Book("corejava", 108, 2017,4,23);
		books[2] = new Book("Head First Java", 79, 2016, 3, 01);
		books[1] = new Book("Algorithm", 44, 2017,8,19);
		
		try(DataOutputStream out = new DataOutputStream(new FileOutputStream("D:/book2.dat")))
		{
			// save all book records to the file book2.dat
			
			for(Book b : books)
				writeData(out, b);
		}
		
		try (RandomAccessFile in = new RandomAccessFile("D:/book2.dat", "r"))
		{
			// retrieve all records into a new array
			
			// compute the array size
			int n = (int) (in.length() / Book.RECORD_SIZE);
			Book[] input = new Book[n];
			
			// read books in retrise order
			for (int i = n - 1; i >= 0; i--)
			{
				input[i] = new Book();
				in.seek(i * Book.RECORD_SIZE);
				input[i] = readData(in);
			}
			
			// print the newly read Book records
			for (Book b : input)
			{
				System.out.println(b);
			}
		}
	}
	
	/**
	 * Writes books data to a data output
	 * @param out the data output
	 * @param b the book
	 * @throws IOException
	 */
	public static void writeData(DataOutput out, Book b) throws IOException
	{
		DataIO.writeFixedString(b.getName(), Book.NAME_SIZE, out);
		out.writeDouble(b.getPrice());
		LocalDate buyDay = b.getBuyDay();
		out.writeInt(buyDay.getYear());
		out.writeInt(buyDay.getMonthValue());
		out.writeInt(buyDay.getDayOfMonth());
	}
	
	/**
	 * Read books from the data input
	 * @param in the data input
	 * @return the book
	 * @throws IOException
	 */
	public static Book readData(DataInput in) throws IOException
	{
		String name = DataIO.readFixedString(Book.NAME_SIZE, in);
		double price = in.readDouble();
		int year = in.readInt();
		int month = in.readInt();
		int day = in.readInt();
		return new Book(name, price, year, month - 1, day);
	}
}
