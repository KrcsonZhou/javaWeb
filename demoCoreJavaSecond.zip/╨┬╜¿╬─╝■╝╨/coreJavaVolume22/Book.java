package coreJavaVolume22;

import java.time.LocalDate;
import java.io.*;

public class Book implements Serializable
{
	public static final int NAME_SIZE = 40;
	public static final long RECORD_SIZE = 2 * NAME_SIZE + 8 + 4 + 4 + 4;
	private String name;
	private double price;
	private LocalDate buyDay;
	
	public Book(String name, double price, int year, int month, int day)
	{
		this.name = name;
		this.price = price;
		buyDay = LocalDate.of(year, month, day);
	}
	
	public Book()
	{
		
	}
	public String getName()
	{
		return name;
	}
	public double getPrice()
	{
		return price;
	}
	public LocalDate getBuyDay()
	{
		return buyDay;
	}
	/**
	 * compute the pcice when sales again
	 * @param rate percent of slide
	 */
	public void secondHandRate(double rate)
	{
		price = price - rate / 100;
	}
	@Override
	public String toString()
	{
		return "[ Name = " + getName() + ", Price= " + getPrice()  + ", buyDay= " + getBuyDay().toString() + "]";
	}
}
