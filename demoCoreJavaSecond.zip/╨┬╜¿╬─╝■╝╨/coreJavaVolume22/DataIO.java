package coreJavaVolume22;

import java.io.*;

public class DataIO 
{
	public static void writeFixedString(String s, int size, DataOutput out) throws IOException
	{
		for (int i = 0; i < size; i++)
		{
			char c = 0;
			if ( i < s.length()) c = s.charAt(i);
			out.writeChar(c);
		}
	}
	
	public static String readFixedString(int size, DataInput in) throws IOException
	{
		StringBuilder b = new StringBuilder(size);
		
		int i = 0;
		boolean m = true;
		while(m && i < size)
		{
			char c = in.readChar();
			i++;
			if(c == 0) 
				m = false;
			else 
				b.append(c);
		}
		in.skipBytes(2 * (size - i));
		return b.toString();
	}
}
