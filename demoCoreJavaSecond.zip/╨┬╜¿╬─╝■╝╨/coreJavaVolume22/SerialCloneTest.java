package coreJavaVolume22;

import java.io.*;

public class SerialCloneTest {

}
