package coreJavaVolume22;

import java.io.*;
import java.util.*;
import java.time.*;

/**
 * @version 1.14 2016-07-11
 * @author Horstmann   
 */
public class TextFileTest 
{
	public static void main(String[] args) throws IOException
	{
		Book[] books = new Book[3];
		
		books[0] = new Book("Core Java Volume 1", 39.59, 2016,9,1);
		books[1] = new Book("Core java Volume 2", 119.26, 2017, 4, 15);
		books[2] = new Book("Algorithms", 13.45, 2017, 9, 12);
		
		// save all books records to the file book.dat
		try(PrintWriter out = new PrintWriter("D:/book.dat", "UTF-8"))
		{
			writeData(books, out);
		}
		
		// retreve all records into a new array
		try (Scanner in = new Scanner(new FileInputStream("D:/book.dat"), "UTF-8"))
		{
			Book[] newBooks = readData(in);
			
			// print the newly read book records
			for (Book b : newBooks)
				System.out.println(b);
		}
	}
	
	/**
	 * Writes all books in an array to a print writer
	 * @param books an array of books
	 * @param out a print writer
	 */
	private static void writeData(Book[] books, PrintWriter out) throws IOException
	{
		// write number of books
		out.println(books.length);
		
		for (Book book : books)
			writeBook(out, book);
	}
	
	/**
	 * Reads an array of books from a scanner
	 * @param in the scanner
	 * @return the array of book
	 */
	private static Book[] readData(Scanner in)
	{
		// retrieve the array size
		int n = in.nextInt();
		in.nextLine(); // consume new line
		
		Book[] books = new Book[10];
		for (int i = 0; i < n; i++)
		{
			books[i] = readBook(in);
		}
		return books;
	}
	
	/**
	 * Writes book data to a print writer
	 * @param out the print writer
	 */
	public static void writeBook(PrintWriter out, Book book)
	{
		out.println(book.getName() + "|" + book.getPrice() + "|" + book.getBuyDay().toString());
	}
	
	/**
	 * Reads book data from a buffered reader
	 * @param in the scanner
	 */
	public static Book readBook(Scanner in)
	{
		String line = in.nextLine();
		String[] tokens = line.split("\\|");
		String name = tokens[0];
		double price = Double.parseDouble(tokens[1]);
		LocalDate buyDay = LocalDate.parse(tokens[2]);
		int year = buyDay.getYear();
		int month = buyDay.getMonthValue();
		int day = buyDay.getDayOfMonth();
		return new Book(name, price, year, month, day);
	}
}
