package coreJavaVolume21;

import java.util.List;
import java.util.Arrays;
import java.util.stream.Stream;
import java.util.Optional;
import java.util.Comparator;
import java.util.NoSuchElementException;


public class AnotherStreamTest 
{
	public static void main(String[] args)
	{
		Integer[] array = new Integer[100];
		for(int i = 0; i < array.length; i++)
		{
			 array[i]  = i + 1;
		}
		
		List<Integer> list = Arrays.asList(array);
		
		{
			System.out.println(Optional.of(new Integer(4)).orElse(new Integer(0)));
			System.out.println(Optional.empty().orElse(new Integer(5)));
			System.out.println(doubleInt(0).orElseGet(() -> doubleInt(10).get()));
		}
		
	}
	public static Optional<Integer> doubleInt(Integer multiplier)
	{
		return multiplier == 0? Optional.empty() : Optional.of(multiplier * multiplier);
	}
}
