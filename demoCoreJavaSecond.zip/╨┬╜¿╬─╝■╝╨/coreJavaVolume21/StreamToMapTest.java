package coreJavaVolume21;

import java.io.*;
import java.util.*;
import java.util.function.*;
import java.util.stream.*;

public class StreamToMapTest 
{
	public static class People
	{
		private int identity;
		private String called;
		
		public People(int identity, String called)
		{
			this.identity = identity;
			this.called = called;
		}
		public int getIdentity()
		{
			return identity;
		}
		public String getSocalled()
		{
			return called;
		}
		@Override
		public String toString()
		{
			return getClass().getName() + "[id= " + identity + ",name= " + called + "]";
		}
		
		public static Stream<People> persons()
		{
			return Stream.of(new People(1001, "Peter"), new People(1002, "Pual"), new People(1003, "Mary"));
		}
	}
	
	public static void main(String[] args) throws IOException
	{
		Map<Integer, String> idToName = People.persons().collect(Collectors.toMap(People::getIdentity, People::getSocalled));
		System.out.println("IdToName: " + idToName);
		
		Map<Integer, People> idToPeople = People.persons().collect
				(
						Collectors.toMap(
								People::getIdentity,
								Function.identity()));
		System.out.println("idToPeople" + idToPeople.getClass().getName() + idToPeople);
		
		idToPeople = People.persons().collect(
				Collectors.toMap(People::getIdentity, Function.identity(), (
						existValue, newValue) -> {
							throw new IllegalStateException();
						}, TreeMap::new));
		System.out.println("idToPeople: " + idToPeople.getClass().getName() + idToPeople);
		
		Stream<Locale> locales = Stream.of(Locale.getAvailableLocales());
		Map<String, String> languageNames = locales.collect(Collectors.toMap(Locale::getDisplayLanguage, l -> l.getDisplayLanguage(l), 
				(existingValue, newValue) -> existingValue));
		System.out.println("LanguageNames" + languageNames);
		
		locales = Stream.of(Locale.getAvailableLocales());
		Map<String, Set<String>> countryLanguageSets = locales.collect(
				Collectors.toMap(
						Locale::getDisplayCountry,
						l -> Collections.singleton(l.getDisplayLanguage()),
						(a, b) ->
						{
							// union of a and b
							Set<String> union = new HashSet<>(a);
							union.addAll(b);
							return union;
						}));
		System.out.println("countryLanguageSets: " + countryLanguageSets);
	}
	
}
