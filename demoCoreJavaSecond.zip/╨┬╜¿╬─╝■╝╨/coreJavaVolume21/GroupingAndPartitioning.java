package coreJavaVolume21;

import java.io.*;
import java.util.*;
import java.util.stream.*;
import java.util.function.*;

public class GroupingAndPartitioning 
{
	public static void main(String[] args)
	{
		Stream<Locale> one = Stream.of(Locale.getAvailableLocales());
		Map<String, List<Locale>> countryCode = one.collect(Collectors.groupingBy(Locale::getCountry));
		List<Locale> swissLocale = countryCode.get("CH");
		for(Locale s : swissLocale)
		{
			System.out.println(s);
		}
		System.out.println("............");
		Stream<Locale> two = Stream.of(Locale.getAvailableLocales());
		Map<Boolean, List<Locale>> part = two.collect(Collectors.partitioningBy(l -> l.getLanguage().equals("en")));
		List<Locale> yesEnglish = part.get(true);
		for(Locale k : yesEnglish)
		{
			System.out.println(k);
		}
	}
}
