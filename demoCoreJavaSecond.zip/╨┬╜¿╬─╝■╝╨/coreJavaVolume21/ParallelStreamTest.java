package coreJavaVolume21;

import java.io.*;
import java.nio.charset.*;
import java.nio.file.*;
import java.util.*;
import java.util.stream.*;

public class ParallelStreamTest 
{
	public static void main(String[] args) throws IOException
	{
		String contents = new String(Files.readAllBytes(Paths.get("D:/Java/jdk/corejava/gutenberg/alice30.txt")), StandardCharsets.UTF_8);
		List<String> wordList = Arrays.asList(contents.split("\\PL+"));
		
		int[] shortWords = new int[10];
		wordList.parallelStream().forEach(s -> {
			if (s.length() < 10) shortWords[s.length()] ++;
		});
		System.out.println(Arrays.toString(shortWords));
		
		Arrays.fill(shortWords, 0);
		wordList.parallelStream().forEach( s -> {
			if (s.length() < 10) shortWords[s.length()] ++;
		});
		System.out.println(Arrays.toString(shortWords));
		
		Map<Integer, Long> lengCount = wordList.parallelStream().collect(Collectors.groupingByConcurrent(String::length, Collectors.counting()));
		System.out.println(lengCount);
		
		Map<Integer, Long> lengCount1 = wordList.parallelStream().collect(Collectors.groupingByConcurrent(String::length, Collectors.counting()));
		System.out.println(lengCount1);
		
		Map<Integer, List<String>> result = wordList.parallelStream().collect(Collectors.groupingByConcurrent(String::length));
		System.out.println(result.get(10));
		
		Map<Integer, List<String>> result2 = wordList.parallelStream().collect(Collectors.groupingByConcurrent(String::length));
		System.out.println(result2.get(10));
		
		
	}
}
