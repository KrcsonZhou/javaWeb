package coreJavaVolume21;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
public class StreamMethodTest 
{
	public static Stream<String> increse(String w, String add)
	{
		List<String> result = new ArrayList<>();
		for (int i = 0; i < w.length(); i++)
		{
			result.add(w + add);
		}
		return result.stream();
	}
	public static void main(String[] args) throws IOException
	{
	   Path count = Paths.get("D:/Java/jdk/corejava/gutenberg/crsto10.txt");
	   byte[] fileContext = Files.readAllBytes(count);
	   String content = new String(fileContext, StandardCharsets.UTF_8);
	   
	   Stream<String> words = Stream.of(content.split("\\PL+"));
	   
	   words.limit(100).filter(w -> w.contains("p")).forEach(s -> System.out.println(s));
	   Stream<String> words1 = Stream.of(content.split("\\PL+"));
	   Stream<String> replace = words1.limit(100).map(s -> s.substring(0,1));
	   replace.forEach(s -> System.out.println(s));
	   Stream<String> words2 = Stream.of(content.split("\\PL+"));
	   words2.limit(100).flatMap(w -> increse(w, " plus")).forEach(s -> System.out.println(s));
	}
}
