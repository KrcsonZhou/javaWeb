package coreJavaVolume21;

import java.io.*;
import java.nio.charset.*;
import java.nio.file.*;
import java.util.*;

public class OptionalTest 
{
	public static void main(String[] args) throws IOException
	{
		Path paths = Paths.get("D:/Java/jdk/corejava/gutenberg/alice30.txt");
		byte[] file = Files.readAllBytes(paths);
		String contents = new String(file, StandardCharsets.UTF_8);
		
		List<String> wordList = Arrays.asList(contents.split("\\PL+"));
		
		Optional<String> optionalValue = wordList.stream().filter(v -> v.contains("fred")).findFirst();
		System.out.println(optionalValue.orElse("No word") + " contains fred");
		
		Optional<String> optionalString = Optional.empty();
		String result = optionalString.orElse("N/A");
		System.out.println("Result: " + result);
		
		result = optionalString.orElseGet(() -> Locale.getDefault().getDisplayName());
		System.out.println("\n" + "Result: " + result);
		
		try
		{
			result = optionalString.orElseThrow(IllegalStateException::new);
			System.out.println("No Word can display on console");
		}
		catch(IllegalStateException e)
		{
			e.printStackTrace();
		}
		
		optionalValue = wordList.stream().filter(v -> v.contains("red")).findFirst();
		optionalValue.ifPresent(s -> System.out.println(s + " contains red"));
		
		Set<String> results = new HashSet<>();
		optionalValue.ifPresent(results::add);
		Optional<Boolean> added = optionalValue.map(results::add);
		System.out.println(added);
		System.out.println(inverse(4.0).flatMap(OptionalTest::squareRoot));
		System.out.println(inverse(-2.0).flatMap(OptionalTest::squareRoot));
		System.out.println(inverse(0.0).flatMap(OptionalTest::squareRoot));
		
		Optional<Double> result2 = Optional.of(-4.0).flatMap(OptionalTest::inverse).flatMap(OptionalTest::squareRoot);
		System.out.println("Final result: " + result2);
		}
	public static Optional<Double> inverse(Double d)
	{
		return d == 0 ? Optional.empty() : Optional.of(1 / d);
	}
	public static Optional<Double> squareRoot(Double d)
	{
	    return d < 0 ? Optional.empty() : Optional.of(Math.sqrt(d));
	}
}
