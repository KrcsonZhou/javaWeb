package coreJavaVolume21;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
public class ToStream 
{
	public static void main(String[] args) throws IOException
	{
		Path path1 = Paths.get("D:/Java/jdk/corejava/gutenberg/alice30.txt");
		byte[] readfile = Files.readAllBytes(path1);
		String contents = new String(readfile, StandardCharsets.UTF_8);
		List<String> words = Arrays.asList(contents.split("\\PL+"));
		
		long count = 0;
		for (String w : words)
		{
			if(w.length() > 13) count++;
		}
		System.out.println(count);
		
		count = words.stream().filter(w -> w.length() > 13).count();
		
		System.out.println(count);
		
		count = words.parallelStream().filter(w -> w.length() > 13).count();
		
		System.out.println(count);
	}
}
