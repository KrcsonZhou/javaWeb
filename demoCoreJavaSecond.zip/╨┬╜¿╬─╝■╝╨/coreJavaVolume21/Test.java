package coreJavaVolume21;


public class Test 
{
}
